package com.example.wsg.helpers;

public class DaySchedule {

    private String employeeNames;

    public DaySchedule(String employeeNames) {
        this.employeeNames = employeeNames;
    }

    public String getEmployeeNames() {
        return employeeNames;
    }

    public void setEmployeeNames(String employeeNames) {
        this.employeeNames = employeeNames;
    }
}
